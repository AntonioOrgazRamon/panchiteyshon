const { z } = require('zod');
const { TIPOS, ESTADOS, PRIORIDADES } = require('../models/tarea.model');

const tareaSchema = z.object({
  titulo: z.string().min(1, 'Título requerido').max(200),
  descripcion: z.string().max(2000).optional().default(''),
  tipo: z.enum(TIPOS),
  estado: z.enum(ESTADOS),
  prioridad: z.enum(PRIORIDADES),
  leadId: z.string().nullable().optional(),
  fechaVencimiento: z.coerce.date().nullable().optional(),
  fechaRecordatorio: z.coerce.date().nullable().optional(),
  completada: z.boolean().optional().default(false),
});

const tareaPartialSchema = tareaSchema.partial();

function validateTarea(body) {
  return tareaSchema.safeParse(body);
}

function validateTareaPartial(body) {
  return tareaPartialSchema.safeParse(body);
}

module.exports = { validateTarea, validateTareaPartial };
