const { v4: uuidv4 } = require('uuid');
const { TIPOS, ESTADOS, PRIORIDADES } = require('../models/tarea.model');

function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function addDays(d, days) {
  const out = new Date(d);
  out.setDate(out.getDate() + days);
  return out;
}

function generateTareas(leadIds, count = 20) {
  const tareas = [];
  const titulos = [
    'Llamar para seguimiento',
    'Enviar propuesta por email',
    'Reunión de cierre',
    'Recordatorio: enviar catálogo',
    'Revisar contrato',
    'Coordinar visita',
    'Enviar presupuesto actualizado',
  ];

  for (let i = 0; i < count; i++) {
    const fechaVenc = addDays(new Date(), -5 + Math.floor(Math.random() * 30));
    const recordatorio = Math.random() > 0.4 ? addDays(fechaVenc, -2) : null;
    const estado = random(ESTADOS);
    const completada = estado === 'hecha';

    tareas.push({
      id: uuidv4(),
      titulo: titulos[i % titulos.length],
      descripcion: i % 2 === 0 ? 'Seguimiento post contacto.' : '',
      tipo: random(TIPOS),
      estado,
      prioridad: random(PRIORIDADES),
      leadId: leadIds[i % leadIds.length],
      fechaVencimiento: fechaVenc,
      fechaRecordatorio: recordatorio,
      completada,
      createdAt: addDays(fechaVenc, -7),
      updatedAt: new Date(),
    });
  }
  return tareas;
}

module.exports = { generateTareas };
