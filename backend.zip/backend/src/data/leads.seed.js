const { v4: uuidv4 } = require('uuid');

const CANALES = ['whatsapp', 'instagram', 'llamada', 'web', 'referido', 'otro'];
const ESTADOS = ['nuevo', 'contactado', 'interesado', 'reunion', 'propuesta', 'cerrado', 'perdido'];
const PRIORIDADES = ['baja', 'media', 'alta'];

const empresas = [
  'Pizzería Don Carlo', 'Bar La Esquina', 'Panadería San José', 'Café Central',
  'Restaurante El Puerto', 'Gimnasio FitLife', 'Peluquería Estilo', 'Ferretería El Martillo',
  'Farmacia Salud', 'Supermercado El Ahorro', 'Taller Mecánico Rápido', 'Clínica Dental Sonrisa',
  'Veterinaria Patitas', 'Lavandería Express', 'Imprenta Gráfica', 'Academia de Inglés',
  'Tienda de Bicis', 'Óptica Vista Clara', 'Florería Jardín', 'Carnicería La Mejor',
];

function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function addDays(d, days) {
  const out = new Date(d);
  out.setDate(out.getDate() + days);
  return out;
}

function generateLeads(count = 20) {
  const leads = [];
  const usedPhones = new Set();
  const usedEmails = new Set();

  for (let i = 0; i < count; i++) {
    let telefono = `+54 9 11 ${1000 + i}${1000 + i}${1000 + i}`;
    while (usedPhones.has(telefono)) {
      telefono = `+54 9 11 ${Math.floor(1000000 + Math.random() * 8999999)}`;
    }
    usedPhones.add(telefono);

    const emailName = empresas[i].toLowerCase().replace(/\s+/g, '');
    let email = `${emailName}@ejemplo.com`;
    if (usedEmails.has(email)) email = `contacto${i}@ejemplo.com`;
    usedEmails.add(email);

    const fechaAlta = addDays(new Date(), -Math.floor(Math.random() * 90));
    const ultimoContacto = Math.random() > 0.3 ? addDays(fechaAlta, Math.floor(Math.random() * 30)) : null;

    leads.push({
      id: uuidv4(),
      nombre: `Contacto ${empresas[i]}`,
      empresa: empresas[i],
      telefono,
      email,
      canalOrigen: random(CANALES),
      estadoPipeline: random(ESTADOS),
      ticketEstimado: [0, 50000, 100000, 150000, 200000][Math.floor(Math.random() * 5)],
      prioridad: random(PRIORIDADES),
      localidad: ['CABA', 'GBA Norte', 'GBA Sur', 'La Plata', 'Córdoba'][i % 5],
      notas: i % 3 === 0 ? 'Cliente potencial interesado en presupuesto.' : '',
      activo: Math.random() > 0.2,
      fechaAlta,
      ultimoContacto,
      createdAt: fechaAlta,
      updatedAt: new Date(),
    });
  }
  return leads;
}

module.exports = { generateLeads };
