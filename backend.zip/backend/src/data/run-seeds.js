const { generateLeads } = require('./leads.seed');
const { generateInteracciones } = require('./interacciones.seed');
const { generateTareas } = require('./tareas.seed');

const leads = generateLeads(20);
const leadIds = leads.map((l) => l.id);
const interacciones = generateInteracciones(leadIds, 40);
const tareas = generateTareas(leadIds, 20);

module.exports = {
  seedLeads: () => [...leads],
  seedInteracciones: () => [...interacciones],
  seedTareas: () => [...tareas],
};
