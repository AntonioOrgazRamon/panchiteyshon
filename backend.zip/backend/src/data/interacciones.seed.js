const { v4: uuidv4 } = require('uuid');
const { TIPOS, DIRECCIONES, RESULTADOS } = require('../models/interaccion.model');

function random(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function addDays(d, days) {
  const out = new Date(d);
  out.setDate(out.getDate() + days);
  return out;
}

function generateInteracciones(leadIds, count = 40) {
  const interacciones = [];
  const resumenes = [
    'Llamada inicial, dejó mensaje.',
    'Respondió por WhatsApp, pide presupuesto.',
    'Reunión de presentación, muy interesado.',
    'Envió email con requisitos.',
    'No contestó, reintentar en una semana.',
    'Pidió tiempo para decidir.',
    'Cierre positivo, enviar propuesta formal.',
  ];

  for (let i = 0; i < count; i++) {
    const leadId = leadIds[i % leadIds.length];
    const fechaInteraccion = addDays(new Date(), -Math.floor(Math.random() * 60));
    const proximaAccion = Math.random() > 0.5 ? addDays(fechaInteraccion, 3 + Math.floor(Math.random() * 10)) : null;

    interacciones.push({
      id: uuidv4(),
      leadId,
      tipo: random(TIPOS),
      direccion: random(DIRECCIONES),
      resumen: random(resumenes),
      resultado: random(RESULTADOS),
      fechaInteraccion,
      proximaAccionFecha: proximaAccion,
      duracionMin: Math.random() > 0.5 ? 5 + Math.floor(Math.random() * 25) : null,
      createdAt: fechaInteraccion,
      updatedAt: new Date(),
    });
  }
  return interacciones;
}

module.exports = { generateInteracciones };
