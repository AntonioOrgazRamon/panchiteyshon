const { v4: uuidv4 } = require('uuid');
const { createTarea } = require('../models/tarea.model');
const { seedTareas } = require('../data/run-seeds');
const leadRepo = require('./lead.repository.memory');

let store = [];
let leadIdsCache = [];

function init() {
  leadIdsCache = leadRepo.findAllSync().map((l) => l.id);
  store = seedTareas(leadIdsCache, 20).map((t) => ({ ...t }));
}

function refreshLeadIds() {
  leadIdsCache = leadRepo.findAllSync().map((l) => l.id);
}

function findAll() {
  return Promise.resolve([...store]);
}

function findById(id) {
  return Promise.resolve(store.find((t) => t.id === id) ?? null);
}

function findByLeadId(leadId) {
  return Promise.resolve(store.filter((t) => t.leadId === leadId));
}

function findPaginated({ page = 1, limit = 10, estado = '', prioridad = '', leadId = '' }) {
  let list = [...store];
  if (estado) list = list.filter((t) => t.estado === estado);
  if (prioridad) list = list.filter((t) => t.prioridad === prioridad);
  if (leadId) list = list.filter((t) => t.leadId === leadId);

  const total = list.length;
  const start = (page - 1) * limit;
  const data = list.slice(start, start + limit);
  return Promise.resolve({ data, total, page, limit, totalPages: Math.ceil(total / limit) });
}

function findUpcoming(days = 7) {
  const limitDate = new Date();
  limitDate.setDate(limitDate.getDate() + days);
  const now = new Date();
  const list = store.filter(
    (t) =>
      t.estado !== 'hecha' &&
      t.estado !== 'cancelada' &&
      t.fechaVencimiento &&
      new Date(t.fechaVencimiento) >= now &&
      new Date(t.fechaVencimiento) <= limitDate
  );
  return Promise.resolve(list);
}

function create(data) {
  refreshLeadIds();
  const now = new Date();
  const tarea = {
    ...createTarea(data),
    id: data.id || uuidv4(),
    createdAt: now,
    updatedAt: now,
  };
  store.push(tarea);
  return Promise.resolve(tarea);
}

function update(id, data) {
  const idx = store.findIndex((t) => t.id === id);
  if (idx === -1) return Promise.resolve(null);
  const updated = { ...store[idx], ...data, id: store[idx].id, updatedAt: new Date() };
  store[idx] = updated;
  return Promise.resolve(updated);
}

function remove(id) {
  const idx = store.findIndex((t) => t.id === id);
  if (idx === -1) return Promise.resolve(false);
  store.splice(idx, 1);
  return Promise.resolve(true);
}

init();

module.exports = {
  init,
  findAll,
  findById,
  findByLeadId,
  findPaginated,
  findUpcoming,
  create,
  update,
  remove,
};
