const mongoose = require('mongoose');

const TIPOS = ['seguimiento', 'reunion', 'interna', 'recordatorio'];
const ESTADOS = ['pendiente', 'en_progreso', 'hecha', 'cancelada'];
const PRIORIDADES = ['baja', 'media', 'alta'];

const tareaSchema = new mongoose.Schema(
  {
    titulo: { type: String, required: true, maxlength: 200 },
    descripcion: { type: String, maxlength: 2000, default: '' },
    tipo: { type: String, enum: TIPOS, default: 'seguimiento' },
    estado: { type: String, enum: ESTADOS, default: 'pendiente' },
    prioridad: { type: String, enum: PRIORIDADES, default: 'media' },
    leadId: { type: mongoose.Schema.Types.ObjectId, ref: 'Lead', default: null },
    fechaVencimiento: { type: Date, default: null },
    fechaRecordatorio: { type: Date, default: null },
    completada: { type: Boolean, default: false },
  },
  { timestamps: true }
);

tareaSchema.index({ leadId: 1 });
tareaSchema.index({ estado: 1 });
tareaSchema.index({ fechaVencimiento: 1 });

const Tarea = mongoose.model('Tarea', tareaSchema);
module.exports = Tarea;
