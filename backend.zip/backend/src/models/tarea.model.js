/**
 * Definición del modelo Tarea.
 */
const TIPOS = ['seguimiento', 'reunion', 'interna', 'recordatorio'];
const ESTADOS = ['pendiente', 'en_progreso', 'hecha', 'cancelada'];
const PRIORIDADES = ['baja', 'media', 'alta'];

function createTarea(overrides = {}) {
  const now = new Date();
  return {
    id: overrides.id ?? null,
    titulo: overrides.titulo ?? '',
    descripcion: overrides.descripcion ?? '',
    tipo: overrides.tipo ?? 'seguimiento',
    estado: overrides.estado ?? 'pendiente',
    prioridad: overrides.prioridad ?? 'media',
    leadId: overrides.leadId ?? null,
    fechaVencimiento: overrides.fechaVencimiento ?? null,
    fechaRecordatorio: overrides.fechaRecordatorio ?? null,
    completada: overrides.completada ?? false,
    createdAt: overrides.createdAt ?? now,
    updatedAt: overrides.updatedAt ?? now,
  };
}

module.exports = {
  TIPOS,
  ESTADOS,
  PRIORIDADES,
  createTarea,
};
