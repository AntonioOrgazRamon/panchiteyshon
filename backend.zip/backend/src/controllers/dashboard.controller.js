const dashboardService = require('../services/dashboard.service');
const { success } = require('../utils/response');

async function getSummary(req, res, next) {
  try {
    const data = await dashboardService.getSummary();
    return success(res, data, 'OK');
  } catch (e) {
    next(e);
  }
}

module.exports = { getSummary };
