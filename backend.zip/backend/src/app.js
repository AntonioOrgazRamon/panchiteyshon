const express = require('express');
const cors = require('cors');
const { config, corsOptions } = require('./config');
const requestLogger = require('./middlewares/requestLogger');
const notFound = require('./middlewares/notFound');
const errorHandler = require('./middlewares/errorHandler');

const leadRoutes = require('./routes/lead.routes');
const interaccionRoutes = require('./routes/interaccion.routes');
const tareaRoutes = require('./routes/tarea.routes');
const dashboardRoutes = require('./routes/dashboard.routes');

const app = express();

app.use(cors(corsOptions));
app.use(express.json());
app.use(requestLogger);

app.use('/api/v1/leads', leadRoutes);
app.use('/api/v1/interacciones', interaccionRoutes);
app.use('/api/v1/tareas', tareaRoutes);
app.use('/api/v1/dashboard', dashboardRoutes);

app.get('/api/v1/health', (req, res) => {
  res.json({ ok: true, message: 'NakedCRM Lite API', provider: config.dataProvider });
});

app.use(notFound);
app.use(errorHandler);

module.exports = app;
