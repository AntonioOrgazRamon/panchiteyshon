const { leadRepository, tareaRepository } = require('../repositories');

async function getAll() {
  return tareaRepository.findAll();
}

function getById(id) {
  return tareaRepository.findById(id);
}

function getPaginated(params) {
  return tareaRepository.findPaginated(params);
}

function getUpcoming(days = 7) {
  return tareaRepository.findUpcoming(days);
}

async function create(body) {
  if (body.leadId) {
    const lead = await leadRepository.findById(body.leadId);
    if (!lead) {
      const err = new Error('No se puede asignar la tarea a un lead inexistente.');
      err.statusCode = 422;
      throw err;
    }
  }
  if (body.fechaRecordatorio && body.fechaVencimiento) {
    if (new Date(body.fechaRecordatorio) > new Date(body.fechaVencimiento)) {
      const err = new Error('fechaRecordatorio no puede ser posterior a fechaVencimiento.');
      err.statusCode = 422;
      throw err;
    }
  }
  if (body.completada && body.estado !== 'hecha') {
    body.estado = 'hecha';
  }
  return tareaRepository.create(body);
}

async function update(id, body, isPatch = false) {
  const existing = await tareaRepository.findById(id);
  if (!existing) return null;
  if (body.leadId !== undefined && body.leadId !== null) {
    const lead = await leadRepository.findById(body.leadId);
    if (!lead) {
      const err = new Error('Lead inexistente.');
      err.statusCode = 422;
      throw err;
    }
  }
  const fechaVenc = body.fechaVencimiento ? new Date(body.fechaVencimiento) : new Date(existing.fechaVencimiento);
  const fechaRec = body.fechaRecordatorio !== undefined ? body.fechaRecordatorio : existing.fechaRecordatorio;
  if (fechaRec) {
    if (new Date(fechaRec) > fechaVenc) {
      const err = new Error('fechaRecordatorio no puede ser posterior a fechaVencimiento.');
      err.statusCode = 422;
      throw err;
    }
  }
  const merged = isPatch ? { ...existing, ...body } : body;
  if (merged.completada === true && merged.estado !== 'hecha') {
    merged.estado = 'hecha';
  }
  return tareaRepository.update(id, merged);
}

function remove(id) {
  return tareaRepository.remove(id);
}

module.exports = {
  getAll,
  getById,
  getPaginated,
  getUpcoming,
  create,
  update,
  remove,
};
