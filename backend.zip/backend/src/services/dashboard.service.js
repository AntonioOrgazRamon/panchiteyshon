const { leadRepository, interaccionRepository, tareaRepository } = require('../repositories');

async function getSummary() {
  const [leads, interacciones, tareas] = await Promise.all([
    leadRepository.findAll(),
    interaccionRepository.findAll(),
    tareaRepository.findAll(),
  ]);

  const totalLeads = leads.length;
  const leadsActivos = leads.filter((l) => l.activo).length;
  const leadsPorEstado = {};
  leads.forEach((l) => {
    leadsPorEstado[l.estadoPipeline] = (leadsPorEstado[l.estadoPipeline] || 0) + 1;
  });
  const leadsPorCanal = {};
  leads.forEach((l) => {
    leadsPorCanal[l.canalOrigen] = (leadsPorCanal[l.canalOrigen] || 0) + 1;
  });

  const totalInteracciones = interacciones.length;
  const hace30 = new Date();
  hace30.setDate(hace30.getDate() - 30);
  const interaccionesUltimos30Dias = interacciones.filter(
    (i) => new Date(i.fechaInteraccion) >= hace30
  ).length;

  const tareasPendientes = tareas.filter(
    (t) => t.estado !== 'hecha' && t.estado !== 'cancelada'
  ).length;
  const ahora = new Date();
  const tareasVencidas = tareas.filter(
    (t) =>
      t.estado !== 'hecha' &&
      t.estado !== 'cancelada' &&
      t.fechaVencimiento &&
      new Date(t.fechaVencimiento) < ahora
  ).length;
  const tareasPorPrioridad = { baja: 0, media: 0, alta: 0 };
  tareas.forEach((t) => {
    if (tareasPorPrioridad[t.prioridad] !== undefined) tareasPorPrioridad[t.prioridad]++;
  });

  const cerrados = (leadsPorEstado.cerrado || 0);
  const conversionRateBasica = totalLeads > 0 ? Math.round((cerrados / totalLeads) * 100) / 100 : 0;

  const sinRespuesta = interacciones.filter((i) => i.resultado === 'sin_respuesta').length;

  return {
    totalLeads,
    leadsActivos,
    leadsPorEstado,
    leadsPorCanal,
    totalInteracciones,
    interaccionesUltimos30Dias,
    tareasPendientes,
    tareasVencidas,
    tareasPorPrioridad,
    conversionRateBasica,
    sinRespuesta,
  };
}

module.exports = { getSummary };
