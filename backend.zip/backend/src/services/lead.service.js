const { leadRepository, interaccionRepository, tareaRepository } = require('../repositories');

function normalizeEmail(email) {
  if (!email || typeof email !== 'string') return '';
  return email.trim().toLowerCase();
}

async function checkDuplicados(telefono, email, excludeId) {
  const byPhone = await leadRepository.findByTelefono(telefono, excludeId);
  if (byPhone) return { duplicate: true, field: 'telefono', message: 'Ya existe un lead con ese teléfono.' };
  const normEmail = normalizeEmail(email);
  if (normEmail) {
    const byEmail = await leadRepository.findByEmail(email, excludeId);
    if (byEmail) return { duplicate: true, field: 'email', message: 'Ya existe un lead con ese email.' };
  }
  return { duplicate: false };
}

async function ensureInteraccionPreviaSiPropuesta(leadId) {
  const list = await interaccionRepository.findByLeadId(leadId);
  return list.length > 0;
}

function getAll() {
  return leadRepository.findAll();
}

function getById(id) {
  return leadRepository.findById(id);
}

function getPaginated(params) {
  return leadRepository.findPaginated(params);
}

async function getInteracciones(leadId) {
  const lead = await leadRepository.findById(leadId);
  if (!lead) return null;
  return interaccionRepository.findByLeadId(leadId);
}

async function getTareas(leadId) {
  const lead = await leadRepository.findById(leadId);
  if (!lead) return null;
  return tareaRepository.findByLeadId(leadId);
}

async function create(body) {
  const dup = await checkDuplicados(body.telefono, body.email, null);
  if (dup.duplicate) {
    const err = new Error(dup.message);
    err.statusCode = 409;
    err.field = dup.field;
    throw err;
  }
  if (body.estadoPipeline === 'propuesta') {
    const err = new Error('No se puede crear un lead en estado "propuesta" sin interacciones previas.');
    err.statusCode = 422;
    throw err;
  }
  if (['cerrado', 'perdido'].includes(body.estadoPipeline) && body.activo !== false) {
    body.activo = false;
  }
  return leadRepository.create(body);
}

async function update(id, body, isPatch = false) {
  const existing = await leadRepository.findById(id);
  if (!existing) return null;

  const dup = await checkDuplicados(
    body.telefono ?? existing.telefono,
    body.email !== undefined ? body.email : existing.email,
    id
  );
  if (dup.duplicate) {
    const err = new Error(dup.message);
    err.statusCode = 409;
    err.field = dup.field;
    throw err;
  }

  if ((body.estadoPipeline ?? existing.estadoPipeline) === 'propuesta') {
    const interacciones = await interaccionRepository.findByLeadId(id);
    if (interacciones.length === 0) {
      const err = new Error('No se puede poner estado "propuesta" sin al menos una interacción previa.');
      err.statusCode = 422;
      throw err;
    }
  }

  if (['cerrado', 'perdido'].includes(body.estadoPipeline ?? existing.estadoPipeline)) {
    body.activo = false;
  }

  return leadRepository.update(id, isPatch ? { ...existing, ...body } : body);
}

function remove(id) {
  return leadRepository.remove(id);
}

module.exports = {
  getAll,
  getById,
  getPaginated,
  getInteracciones,
  getTareas,
  create,
  update,
  remove,
  checkDuplicados,
};
