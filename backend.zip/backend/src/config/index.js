/**
 * Configuración centralizada del backend.
 * Cargamos .env desde la carpeta backend (no desde cwd) para que funcione
 * aunque el servidor se arranque desde otra ruta.
 */
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  dataProvider: process.env.DATA_PROVIDER || 'memory',
  corsOrigin: process.env.CORS_ORIGIN || 'http://localhost:4200,http://localhost:5173',
  mongoUri: process.env.MONGO_URI || 'mongodb://localhost:27017/nakedcrm',
};

const corsOptions = {
  origin: config.corsOrigin.split(',').map((o) => o.trim()),
  optionsSuccessStatus: 200,
};

module.exports = { config, corsOptions };
